package app;

import app.game.BlackJack;

public class StartGame {

	public static void main(String[] args) {
		System.out.println("BlackJack-01");
		BlackJack blackJack = new BlackJack();
	}

}
